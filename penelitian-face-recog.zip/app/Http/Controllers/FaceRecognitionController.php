<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class FaceRecognitionController extends Controller
{
    public function attendance()
    {
        return view('attendance.face_recognition');
    }

    public function recognize(Request $request)
    {
        $image = $request->input('image');

        $response = Http::post('http://localhost:5000/recognize', [
            'image' => $image
        ]);

        return response()->json($response->json());
    }
}

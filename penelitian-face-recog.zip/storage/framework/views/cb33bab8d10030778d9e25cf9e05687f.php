<!DOCTYPE html>
<html>
<head>
    <title>Absensi Wajah Siswa</title>
</head>
<body>
    <form action="/detect-faces" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="file" name="image">
        <button type="submit">Unggah dan Deteksi Wajah</button>
    </form>
</body>
</html>
<?php /**PATH C:\Users\dhima\Downloads\penelitian-face-recog\resources\views/detect_faces.blade.php ENDPATH**/ ?>
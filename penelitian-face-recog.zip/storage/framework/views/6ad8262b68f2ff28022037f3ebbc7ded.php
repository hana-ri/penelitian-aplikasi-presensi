<form method="POST" action="<?php echo e(url('localhost/moodle')); ?>">
    <?php echo csrf_field(); ?>
    <div>
        <label>Username</label>
        <input type="text" name="username" required>
    </div>
    <div>
        <label>Password</label>
        <input type="password" name="password" required>
    </div>
    <button type="submit">Login</button>
</form>
<?php /**PATH C:\Users\dhima\Downloads\penelitian-face-recog\resources\views/welcome.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Face Recognition</title>
</head>
<body>
    <h1>Face Recognition</h1>
    <video id="video" width="640" height="480" autoplay></video>
    <button id="capture">Capture</button>
    <canvas id="canvas" style="display:none;"></canvas>
    <form method="POST" action="{{ route('moodle.logout') }}">
        @csrf
        <button type="submit">Logout</button>
    </form>
    <script>
        async function setupCamera() {
            const stream = await navigator.mediaDevices.getUserMedia({ video: true });
            document.getElementById('video').srcObject = stream;
        }

        setupCamera();

        document.getElementById('capture').addEventListener('click', async () => {
            const video = document.getElementById('video');
            const canvas = document.getElementById('canvas');
            const context = canvas.getContext('2d');
            context.drawImage(video, 0, 0, canvas.width, canvas.height);
            const dataUrl = canvas.toDataURL('image/jpeg');
            const base64Image = dataUrl.split(',')[1];

            const response = await fetch('/recognize', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                },
                body: JSON.stringify({ image: base64Image })
            });

            const result = await response.json();
            if (result.status === 'success') {
                alert(`Wajah Dikenali dengan Nama: ${result.name}`);
            } else {
                alert('Wajah Tidak Dikenali');
            }
        });
    </script>
</body>
</html>

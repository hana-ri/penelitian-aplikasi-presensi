<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MoodleLoginController;
use App\Http\Controllers\FaceRecognitionController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return redirect()->route('moodle.login');
});

Route::get('moodle-login', [MoodleLoginController::class, 'showLoginForm'])->name('moodle.login');
Route::post('moodle-login', [MoodleLoginController::class, 'login']);
Route::post('moodle-logout', [MoodleLoginController::class, 'logout'])->name('moodle.logout');

// Protected routes for Admin
Route::middleware(['auth:moodle', 'admin'])->group(function () {
    Route::get('/dashboard', function () {
        return view('dashboard'); // Ganti dengan controller yang sesuai jika diperlukan
    })->name('dashboard');
});

// Protected routes for Murid
Route::middleware(['auth:moodle', 'murid'])->group(function () {
    Route::get('/attendance', function () {
        return view('attendance.face_recognition'); // Ganti dengan controller yang sesuai jika diperlukan
    })->name('attendance');
});

Route::post('/recognize', [FaceRecognitionController::class, 'recognize']);
